package es.indra;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import es.indra.models.Producto;


//  Netty started on port 62906
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
//@SpringBootTest(webEnvironment = WebEnvironment.MOCK)
class Ejemplo9ClienteRestControllerApplicationTests {
	
	@Autowired
	private WebTestClient clienteTest;
	
	// 3 formas de lanzar las pruebas:
	// Run as / Maven test
	// Run as / JUnit test
	// Desde consola, posicionar dentro del proyecto:  mvnw test   en windows
	// Desde consola, posicionar dentro del proyecto:  ./mvnw test   en mac y linux

	@Test
	public void todosTest2() {
		
		clienteTest.get()
			.uri("/cliente/productos")
			.exchange()
			.expectStatus().isOk()
			.expectHeader().contentType(MediaType.APPLICATION_JSON)
			.expectBodyList(Producto.class)
			.consumeWith(respuesta -> {
				List<Producto> productos = respuesta.getResponseBody();
				Assertions.assertThat(productos.size() == 14).isTrue();
			});
	}
	
	@Test
	public void todosTest() {
		
		clienteTest.get()
			.uri("/cliente/productos")
			.exchange()
			.expectStatus().isOk()
			.expectHeader().contentType(MediaType.APPLICATION_JSON)
			.expectBodyList(Producto.class);
	}

}
