package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Producto;
import es.indra.services.ProductosService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/cliente")   //http://localhost:8081/cliente/productos
public class ProductosREST {
	
	@Autowired
	private ProductosService service;
	
	@GetMapping("/productos")
	public Flux<Producto> todos(){
		return service.todos();
	}
	
	@GetMapping("/productos/{id}")
	public Mono<Producto> buscar(@PathVariable String id){
		return service.buscarProducto(id);
	}
	
	
	@PostMapping("/productos")
	public Mono<Producto> crearNuevo(@RequestBody Producto nuevo){
		return service.insertar(nuevo);
	}
	
	@PutMapping("/productos/{id}")
	public Mono<Producto> modificar(@PathVariable String id, @RequestBody Producto modificado){
		modificado.setId(id);
		return service.modificar(modificado);
	}
	
	
	@DeleteMapping("/productos/{id}")
	public Mono<Void> borrarPorId(@PathVariable String id){
		return service.borrar(id);
	}
	
}












