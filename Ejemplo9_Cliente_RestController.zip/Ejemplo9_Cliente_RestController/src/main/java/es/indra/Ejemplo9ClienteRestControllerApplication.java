package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class Ejemplo9ClienteRestControllerApplication {
	
	// En Spring MVC para comunucarnos entre microservicios
	// o llamar a un Rest se puede hacer con 
	//		- RestTemplate
	//		- Feign
	
	// En Programacion Reactiva se sugiere utilizar WebClient
	
	@Bean
	public WebClient webClient(){
		return WebClient.create("http://localhost:8080/api/productos");
	}
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo9ClienteRestControllerApplication.class, args);
	}

}
