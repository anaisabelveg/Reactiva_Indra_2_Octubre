package es.indra.services;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import es.indra.models.Producto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductosServiceImpl implements ProductosService{
	
	@Autowired
	private WebClient webClient;

	@Override
	public Flux<Producto> todos() {
		return webClient.get()
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToFlux(Producto.class);
	}
	

	@Override
	public Mono<Producto> buscarProducto(String id) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("id", id);
		return webClient.get().uri("/{id}", parametros)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Producto.class);
	}
	
	
	@Override
	public Mono<Producto> insertar(Producto nuevo) {
		return webClient.post()
				.accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromValue(nuevo))
				.retrieve()
				.bodyToMono(Producto.class);
	}

	@Override
	public Mono<Void> borrar(String id) {
		return webClient.delete().uri("/{id}", Collections.singletonMap("id", id))
				.exchange()
				.then();
	}
	
	@Override
	public Mono<Producto> modificar(Producto producto) {
		return webClient.put().uri("/{id}", Collections.singletonMap("id", producto.getId()))
				.accept(MediaType.APPLICATION_JSON)
				.body(BodyInserters.fromValue(producto))
				.retrieve()
				.bodyToMono(Producto.class);
	}
	

	/*
	 
	 @Override
	public Mono<Producto> buscarProducto(String id) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("id", id);
		return webClient.get().uri("/{id}", parametros)
				.accept(MediaType.APPLICATION_JSON)
				.exchange()
				.flatMap(respuesta -> respuesta.bodyToMono(Producto.class));
	}
	  
	 */

}
