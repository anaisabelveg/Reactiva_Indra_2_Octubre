package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Producto;
import es.indra.services.ProductosService;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api")
public class ProductosREST {
	
	@Autowired
	private ProductosService service;
	
	@GetMapping("/productos")
	public Flux<Producto> todos(){
		return service.todos();
	}

}
