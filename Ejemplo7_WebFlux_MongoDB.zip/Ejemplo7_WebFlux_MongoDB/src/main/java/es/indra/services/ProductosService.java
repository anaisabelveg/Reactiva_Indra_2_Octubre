package es.indra.services;

import es.indra.models.Producto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ProductosService {
	
	public Flux<Producto> todos();
	
	public Mono<Producto> buscarProducto(String id);
	
	public Mono<Producto> insertar(Producto nuevo);
	
	public Mono<Void> borrar(Producto producto);
	
	public Mono<Producto> modificar(Producto producto);
}
