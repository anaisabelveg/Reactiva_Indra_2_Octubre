package es.indra.persistence;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import es.indra.models.Producto;

public interface ProductosDAO extends ReactiveMongoRepository<Producto, String>{
	
	
}
