package es.indra.controllers;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.thymeleaf.spring5.context.webflux.ReactiveDataDriverContextVariable;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;
import reactor.core.publisher.Flux;

@Controller
public class ProductosController {
	
	@Autowired
	private ProductosDAO dao;
	
	
	@GetMapping({"/todos", "/"})
	public String todos(Model model) {
		Flux<Producto> productos =  dao.findAll()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
		});
		model.addAttribute("productos", productos);
		return "mostrarTodos";
	}
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("producto", new Producto());
		return "formulario";
	}
	
	@PostMapping("/form")
	public String procesarFormulario(Producto producto) {
		System.out.println(producto);
		return "formulario";
	}
	
	
	@GetMapping("/todos-rdd")
	public String todosRDD(Model model) {
		Flux<Producto> productos =  dao.findAll()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
		}).delayElements(Duration.ofSeconds(2));
		
		// Manejar la contrapresion
		// Enviamos el flujo de productos para que se muestre de 2 en 2
		model.addAttribute("productos", 
				new ReactiveDataDriverContextVariable(productos, 2));
		return "mostrarTodos";
	}
	
	@GetMapping("/todos-repeat")
	public String todosRepeat(Model model) {
		Flux<Producto> productos =  dao.findAll()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
		}).repeat(5000); // cada 5 segundos traiga los productos
		model.addAttribute("productos", productos);
		return "mostrarTodos";
	}
	
	@GetMapping("/todos-chunk")
	public String todosChunk(Model model) {
		Flux<Producto> productos =  dao.findAll()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
		}).repeat(5000); // cada 5 segundos traiga los productos
		model.addAttribute("productos", productos);
		return "mostrarTodos";
	}
	

}










