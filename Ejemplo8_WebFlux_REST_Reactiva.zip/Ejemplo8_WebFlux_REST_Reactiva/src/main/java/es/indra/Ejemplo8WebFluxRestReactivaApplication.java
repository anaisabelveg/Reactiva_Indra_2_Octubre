package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.server.RequestPredicate;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;
import es.indra.rest.HandlerProductos;
import reactor.core.publisher.Flux;

@SpringBootApplication
public class Ejemplo8WebFluxRestReactivaApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;

	
	@Bean
	public RouterFunction<ServerResponse> rutas(HandlerProductos handler){
		return RouterFunctions
				.route(RequestPredicates.GET("/handler/productos"), handler::todos)
				.andRoute(RequestPredicates.GET("/handler/productos/{id}"), handler::buscar)
				.andRoute(RequestPredicates.POST("/handler/productos"), handler::nuevo)
				.andRoute(RequestPredicates.DELETE("/handler/productos/{id}"), handler::borrar)
				.andRoute(RequestPredicates.PUT("/handler/productos/{id}"), handler::modificar);
		
		/*
		return RouterFunctions.route(RequestPredicates.GET("/handler/productos"), request -> 
		handler.todos(request)
		*/

	}
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo8WebFluxRestReactivaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Eliminar la coleccion productos
		mongoTemplate.dropCollection("productos").subscribe();
		
		// Carga inicial de datos
		Flux.just(
				new Producto("Pantalla", 129.95),
				new Producto("Teclado", 56),
				new Producto("Raton", 29.50),
				new Producto("Impresora", 85.25)
		)
		.flatMap(prod -> dao.save(prod))
		.subscribe(prod -> System.out.println(prod));
	}
	
	

}
