package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import es.indra.models.Producto;
import es.indra.services.ProductosService;
import reactor.core.publisher.Mono;

@Component
public class HandlerProductos {
	
	@Autowired
	private ProductosService service;
	
	
	public Mono<ServerResponse> todos(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.todos(), Producto.class);
	}
	
	public Mono<ServerResponse> buscar(ServerRequest request){
		// Comprobar si existe el producto no
		return service.buscarProducto(request.pathVariable("id"))
				.flatMap(p -> ServerResponse
						.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(p), Producto.class))
						.switchIfEmpty(ServerResponse.notFound()
				.build());					
	}
	
	
	public Mono<ServerResponse> modificar(ServerRequest request){
		String id = request.pathVariable("id");
		Producto producto = request.bodyToMono(Producto.class).block();
		producto.setId(id);
		
		return service.buscarProducto(id)
				.flatMap(p -> ServerResponse
							.ok()
							.contentType(MediaType.APPLICATION_JSON)
							.body(service.modificar(producto), Producto.class))
							
				.switchIfEmpty(ServerResponse.notFound().build());
	}
	
	
	public Mono<ServerResponse> borrar(ServerRequest request){
		
		String id = request.pathVariable("id");
		
		return service.buscarProducto(id)
				.flatMap(p -> service.borrar(p)
								.then(ServerResponse.ok().build()))
				.switchIfEmpty(ServerResponse.notFound().build());
	}
	
	
	public Mono<ServerResponse> nuevo(ServerRequest request){
		
		// Recuperar el producto del request
		Mono<Producto> producto = request.bodyToMono(Producto.class);
		
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.insertar(producto.block()), Producto.class);
	}
	
	/*
	public Mono<ServerResponse> buscar(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.buscarProducto(request.pathVariable("id")), Producto.class);
	}*/

}
