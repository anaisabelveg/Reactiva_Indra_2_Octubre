package es.indra.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductosServiceImpl implements ProductosService{
	
	@Autowired
	private ProductosDAO dao;

	@Override
	public Flux<Producto> todos() {
		return dao.findAll();
	}

	@Override
	public Mono<Producto> buscarProducto(String id) {
		return dao.findById(id);
	}

	@Override
	public Mono<Producto> insertar(Producto nuevo) {
		return dao.save(nuevo);
	}

	@Override
	public Mono<Void> borrar(Producto producto) {
		return dao.delete(producto);
	}
	
	@Override
	public Mono<Producto> modificar(Producto producto) {
		return dao.save(producto);
	}

}
