package es.indra.controllers;

import java.time.Duration;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.thymeleaf.spring5.context.webflux.ReactiveDataDriverContextVariable;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;
import es.indra.services.ProductosService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Controller
public class ProductosController {
	
	@Autowired
	private ProductosService service;
	
	
	@GetMapping({"/todos", "/"})
	public String todos(Model model) {
		Flux<Producto> productos = service.todos()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
		});
		model.addAttribute("productos", productos);
		return "mostrarTodos";
	}
	
	@GetMapping("/buscar")
	public String mostrarBuscar(Model model) {
		model.addAttribute("producto", new Producto());
		return "buscar";
	}
	
	@PostMapping("/buscar")
	public String procesarBuscar(Producto producto, Model model) {
		System.out.println(producto);	
		model.addAttribute("encontrado", service.buscarProducto(producto.getId()));
		return "mostrarProducto";
	}
	
	@GetMapping("/modificar/{id}")
	public String mostrarModificar(@PathVariable String id, Model model) {
		model.addAttribute("producto", service.buscarProducto(id));
		return "modificar";
	}
	
	@PostMapping("/modificar")
	public String procesarModificar(@Valid Producto producto, BindingResult resultadoValidacion) {
		
		service.modificar(producto).subscribe();
		
		return "redirect:/todos";
	}
	
	@GetMapping("/eliminar/{id}")
	public Mono<String> eliminar(@PathVariable String id) {
		System.out.println("Id recibido: " + id);
		
		return service.buscarProducto(id)
			.defaultIfEmpty(new Producto())
			.flatMap(p -> {
				if (p.getDescripcion().length() == 0) {
					return Mono.error(new Throwable("El ID de producto no existe"));
				} else {
					service.borrar(p).subscribe();
					return Mono.just(p);
				}
			})
			.then(Mono.just("redirect:/todos"))
			.onErrorResume(error -> Mono.just("mostrarMensaje"));
	}
	
	
	@GetMapping("/form")
	public String mostrarFormulario(Model model) {
		model.addAttribute("producto", new Producto());
		return "formulario";
	}
	
	@PostMapping("/form")
	public String procesarFormulario(@Valid Producto producto, BindingResult resultadoValidacion) {
		
		if (resultadoValidacion.hasErrors()) {
			return "formulario";
		} else {
			service.insertar(producto)
			.doOnNext(p ->  System.out.println("Producto creado " + p))
			.subscribe();
		}
		
		return "redirect:/todos";
	}
	
	@GetMapping("/todos-rdd")
	public String todosRDD(Model model) {
		Flux<Producto> productos =  service.todos()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
		}).delayElements(Duration.ofSeconds(2));
		
		// Manejar la contrapresion
		// Enviamos el flujo de productos para que se muestre de 2 en 2
		model.addAttribute("productos", 
				new ReactiveDataDriverContextVariable(productos, 2));
		return "mostrarTodos";
	}
	
	@GetMapping("/todos-repeat")
	public String todosRepeat(Model model) {
		Flux<Producto> productos =  
				service.todos()
					.map(prod -> {
						prod.setDescripcion(prod.getDescripcion().toUpperCase());
						return prod;
					})
					.delayElements(Duration.ofSeconds(2))
					.repeat(500); // se repite 5 veces
		model.addAttribute("productos", productos);
		return "mostrarTodos";
	}
	
	@GetMapping("/todos-chunk")
	public String todosChunk(Model model) {
		Flux<Producto> productos =  service.todos()
				.map(prod -> {
					prod.setDescripcion(prod.getDescripcion().toUpperCase());
					return prod;
				})
				.delayElements(Duration.ofSeconds(2))
				.repeat(500); // se repite 5 veces
		model.addAttribute("productos", productos);
		return "mostrarTodos";
	}
	

}










