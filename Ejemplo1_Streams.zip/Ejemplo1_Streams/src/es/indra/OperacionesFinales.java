package es.indra;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import es.indra.models.Provincia;
import es.indra.util.Utilidad;

public class OperacionesFinales {

	public static void main(String[] args) {
		
		List<Provincia> provincias = Utilidad.crearLista();
		
		// max
		// Provincia con el mayor numero de habitantes
		Provincia maxHabitantes = provincias.stream()
			.max(Comparator.comparing(Provincia::getPoblacion))
			.get();
		System.out.println(maxHabitantes);
		System.out.println("----------------");
		
		
		// min
		// Provincia con menor densidad de poblacion
		Provincia menorDensidad = provincias.stream()
				.min(Comparator.comparing(Provincia::getDensidadPoblacion))
				.get();
		System.out.println(menorDensidad);
		System.out.println("----------------");
		
		
		// average
		// Media de las localidades por provincia
		double mediaLocalidades = provincias.stream()
				.mapToInt(prov -> prov.getNumLocalidades())
				.average()
				.getAsDouble();
		System.out.println(mediaLocalidades);
		System.out.println("----------------");
		
		
		// sum
		// Sumar todos los habitantes por provincia
		int totalHabitantes = provincias.stream()
				.mapToInt(prov -> prov.getPoblacion())
				.sum();
		System.out.println(totalHabitantes);
		System.out.println("----------------");
		
		
		// collect
		// Crear una lista con las provincias con dialecto Español
		List<Provincia> espanyol = provincias.stream()
				.filter(prov -> "Español".equals(prov.getDialecto()))
				.collect(Collectors.toList());
		espanyol.forEach(System.out::println);
		System.out.println("----------------");
		
		
		// Generar un string con los distintos dialectos separador por -
		String dialectos = provincias.stream()
				.map(prov -> prov.getDialecto())
				.distinct()
				.collect(Collectors.joining(" - "));
		System.out.println(dialectos);
		System.out.println("----------------");
		
		
		// Crear un mapa con las provincias agrupadas por dialecto
		Map<String, List<Provincia>> grupoDialecto = provincias.stream()
				.collect(Collectors.groupingBy(Provincia::getDialecto));
		
		grupoDialecto.forEach( (k, v) -> {
			System.out.println("Dialecto: " + k);
			v.forEach(System.out::println);
		} );
		
		
	}

}
