package es.indra;

import java.util.List;

import es.indra.models.Provincia;
import es.indra.util.Utilidad;

public class OperacionesIntermedias {

	public static void main(String[] args) {
		
		List<Provincia> provincias = Utilidad.crearLista();
		
		
		// Mostrar las provincias que tienen densidad de poblacion superior a 50
		provincias.stream()
			.filter(prov -> prov.getDensidadPoblacion() > 50)
			.map(prov -> prov.getNombre())
			.forEach(System.out::println);
		System.out.println("------------------");
		
		
		// Mostrar los distintos dialectos ordenados
		provincias.stream()
			.map(prov -> prov.getDialecto())
			.distinct()
			.sorted()
			.forEach(System.out::println);
		System.out.println("------------------");
		
		
		// Solo mostrar las 3 primeras provincias
		provincias.stream()
			.limit(3)
			.forEach(System.out::println);
		System.out.println("------------------");
		
		
		// peek -> reaaliza una operacion especifica y devuelve el elemento al stream
		// Util para mostrar resultados intermedios
		provincias.stream()
			.peek(prov -> System.out.println("Procesando " + prov.getNombre() + "-----------"))
			.filter(prov -> prov.getDensidadPoblacion() > 70)
			.peek(prov -> System.out.println("Resultado " + prov.getNombre() + ", Densidad: " + prov.getDensidadPoblacion()))
			.map(prov -> prov.getNombre())
			.forEach(System.out::println);
		System.out.println("------------------");
		
	}
	

}
