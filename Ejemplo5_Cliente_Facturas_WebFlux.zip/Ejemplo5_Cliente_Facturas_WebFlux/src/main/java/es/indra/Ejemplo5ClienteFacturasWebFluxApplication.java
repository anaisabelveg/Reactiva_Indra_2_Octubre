package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Ejemplo5ClienteFacturasWebFluxApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5ClienteFacturasWebFluxApplication.class, args);
	}

}
