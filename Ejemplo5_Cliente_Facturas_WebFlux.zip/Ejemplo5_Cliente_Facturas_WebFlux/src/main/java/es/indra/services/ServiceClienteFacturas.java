package es.indra.services;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import es.indra.models.Factura;
import reactor.core.publisher.Flux;

@Service
public class ServiceClienteFacturas {
	
	public Flux<Factura> getAll(){
		
		
		// Cliente para lanzar la peticion en modo reactiva
		WebClient cliente = WebClient.create("http://localhost:8081/facturas");
		
		long inicio = System.nanoTime();
		
		// Creamos el flujo de datos
		Flux<Factura> facturas = cliente.get().retrieve().bodyToFlux(Factura.class);
		
		long fin = System.nanoTime();
		System.out.println("Tiempo Flux: " + (fin-inicio) + "nanoSeg.");
			
		return facturas;
	}

}
