package es.indra.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.models.Factura;
import es.indra.services.ServiceClienteFacturas;
import reactor.core.publisher.Flux;

@Controller
public class FacturasController {
	
	@Autowired
	private ServiceClienteFacturas serviceClienteFacturas;
	
	// http://localhost:8083/lista
	@RequestMapping("/lista")
	public String todasFacturas(Model modelo) {
				
		List<Factura> lista = serviceClienteFacturas.getAll() // recibimos Flux<Factura>
				.collectList()   // lo convertimos a Mono<List<Factura>>
				.block();  //  lo convertimos List<Factura> y bloque hasta recibir los datos	
		
		// Guardo la lista como un atributo de peticion
		modelo.addAttribute("lista", lista);
		return "vista";
	}

}
