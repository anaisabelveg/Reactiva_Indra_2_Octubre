package es.indra.rest;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Factura;

@RestController
public class ControllerFacturas {
	
	// http://localhost:8081/facturas
	@GetMapping("/facturas")
	public List<Factura> getFacturas(){
		
		List<Factura> facturas = Arrays.asList(
				new Factura(1, "Compra de material", 149.95),
				new Factura(2, "Gastos de viaje", 350),
				new Factura(3, "Pago del alquiler", 1800),
				new Factura(4, "Comida de negocios", 109.50),
				new Factura(5, "Reparacion de maquinaria", 890)
		);
		
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return facturas;
		
	}

}
