package es.indra.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Factura;

@Service
public class ServiceClienteFacturas {
	
	@Autowired
	private RestTemplate template;
	
	public List<Factura> getAll(){
		
		long inicio = System.nanoTime();
		
		Factura[] facturas = template.getForObject("http://localhost:8081/facturas", 
				Factura[].class);
		
		long fin = System.nanoTime();
		System.out.println("Tiempo: " + (fin-inicio) + "nanoSeg.");
		
		return Arrays.asList(facturas);
	}

}
