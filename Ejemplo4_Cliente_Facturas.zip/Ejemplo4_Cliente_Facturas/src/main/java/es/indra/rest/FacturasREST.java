package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.services.ServiceClienteFacturas;

@Controller
public class FacturasREST {
	
	@Autowired
	private ServiceClienteFacturas serviceClienteFacturas;
	
	// http://localhost:8082/todas
	@RequestMapping("/todas")
	public String todasFacturas(Model modelo) {
		// Guardo la lista como un atributo de peticion
		modelo.addAttribute("lista", serviceClienteFacturas.getAll());
		return "vista";
	}

}
