package es.indra;

import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;

import es.indra.business.Publicador;
import es.indra.business.Subscriptor;

public class AppMain {

	public static void main(String[] args) throws InterruptedException {
		
		// Crear el publicador
		SubmissionPublisher<Integer> publicador = new SubmissionPublisher<Integer>();
		
		// Crear el procesador
		Flow.Processor<Integer, Integer> processor = new Publicador();
		
		// Crear el subscriptor
		Flow.Subscriber<Integer> subscriptor = new Subscriptor();
		
		
		publicador.subscribe(processor);
		processor.subscribe(subscriptor);
		
		
		// El publicador queremos que envia 10 numeros
		for(int item = 1; item <= 10; item++) {
			publicador.submit(item);
			Thread.sleep(1); // 2 segundos
		}
		
		// Terminamos el publicador
		publicador.close();

	}

}
