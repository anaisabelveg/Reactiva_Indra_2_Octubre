package es.indra.business;

import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.Flow;
import java.util.concurrent.Flow.Subscription;

public class Publicador extends SubmissionPublisher<Integer> implements Flow.Processor<Integer, Integer>{
	
	private Flow.Subscription subscripcion;

	@Override
	public void onSubscribe(Subscription subscription) {
		// Se subscribe
		this.subscripcion = subscription;
		subscripcion.request(1);	
	}

	@Override
	public void onNext(Integer item) {
		// Enviar mensaje
		submit(item);
		System.out.println("Mensaje enviado: " + item);
		subscripcion.request(1);
	}

	@Override
	public void onError(Throwable error) {
		// Cuando hay errores, funciona como un bloque catch
		error.printStackTrace();
	}

	@Override
	public void onComplete() {
		// Publicador termina
		// Liberar recursos
		System.out.println("El publicador ha terminado");
		
	}

}
