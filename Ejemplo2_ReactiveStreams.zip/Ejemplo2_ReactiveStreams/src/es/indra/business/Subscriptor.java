package es.indra.business;

import java.util.concurrent.Flow;
import java.util.concurrent.Flow.Subscription;

public class Subscriptor implements Flow.Subscriber<Integer>{
	
	private Flow.Subscription subscripcion;

	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscripcion = subscription;
		subscripcion.request(1);
	}

	@Override
	public void onNext(Integer item) {
		System.out.println("Mensaje recibido: " + item);
		subscripcion.request(1);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onError(Throwable error) {
		error.printStackTrace();
	}

	@Override
	public void onComplete() {
		System.out.println("Subscriptor completado");	
	}

}
