package es.indra.models;

import java.util.ArrayList;
import java.util.List;

public class FacturaProductos {

	private Cliente cliente;
	private List<Producto> productos;

	public FacturaProductos() {
		productos = new ArrayList<Producto>();
	}

	public FacturaProductos(Cliente cliente, List<Producto> productos) {
		super();
		this.cliente = cliente;
		this.productos = productos;
	}
	
	public void addProducto(Producto producto) {
		productos.add(producto);
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	@Override
	public String toString() {
		return "FacturaProductos [cliente=" + cliente + ", productos=" + productos + "]";
	}

}
