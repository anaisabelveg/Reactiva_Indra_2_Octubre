package es.indra.models;

public class Cliente {
	
	private String nombre;
	private String cif;
	
	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public Cliente(String nombre, String cif) {
		super();
		this.nombre = nombre;
		this.cif = cif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	@Override
	public String toString() {
		return "Cliente [nombre=" + nombre + ", cif=" + cif + "]";
	}
	
	

}
