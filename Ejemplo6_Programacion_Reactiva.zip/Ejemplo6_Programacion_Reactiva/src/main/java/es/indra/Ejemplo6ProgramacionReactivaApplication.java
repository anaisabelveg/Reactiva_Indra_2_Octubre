package es.indra;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Cliente;
import es.indra.models.Factura;
import es.indra.models.FacturaProductos;
import es.indra.models.Producto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class Ejemplo6ProgramacionReactivaApplication implements CommandLineRunner{
	
	List<Factura> lista = Arrays.asList(
			new Factura(1, "Compra de material", 149.95),
			new Factura(2, "Gastos de viaje", 350),
			new Factura(3, "Pago del alquiler", 1800),
			new Factura(4, "Comida de negocios", 109.50),
			new Factura(5, "Reparacion de maquinaria", 890)
	);

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo6ProgramacionReactivaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		ejemploBloqueos();
	}
	
	public void ejemploBloqueos() throws InterruptedException {
		// Crear un delay (retraso) 
		Flux<Integer> numeros = Flux.range(1, 10)
				.delayElements(Duration.ofSeconds(1))
				.doOnNext(i -> System.out.println(i));
			
		numeros.subscribe();
		
		Thread.sleep(12000);
		
		// Crear un bloqueo
		//numeros.blockLast();
		System.out.println("FIN del metodo");
	}
	
	public void ejemploIntervalos() {
		// Crear un delay (retraso) y combinarlo con otro flujo
		Flux<Integer> numeros = Flux.range(1, 10);
		Flux<Long> delay = Flux.interval(Duration.ofSeconds(1));
		
		numeros.zipWith(delay, (num, retraso) -> num )
			.doOnNext(i -> System.out.println(i))
			.subscribe();
	}
	
	public void facturaConProductosZipWith() {
		
		// Crear un flujo con 1 cliente
		Mono<Cliente> monoCliente = Mono.fromCallable(() -> 
				new Cliente("Juan", "12345678-A"));
		
		// Crear un flujo con 4 productos
		Mono<FacturaProductos> facturaMono = Mono.fromCallable( () -> {
			FacturaProductos fact = new FacturaProductos();
			fact.addProducto(new Producto(1, "Pantalla", 129.95));
			fact.addProducto(new Producto(2, "Teclado", 56));
			fact.addProducto(new Producto(3, "Raton", 29.50));
			fact.addProducto(new Producto(4, "Impresora", 85.25));
			return fact;
		});
				
		
		// Combinar ambos flujos
//		Mono<FacturaProductos> facturaProductosMono =  facturaMono
//			.zipWith(cliente  -> 
//				new FacturaProductos(cliente, f.getProductos()));
//		
//		Mono<FacturaProductos> facturaProductosMono = facturaMono
//				.zipWith(facturaMono)
		
//		facturaProductosMono.subscribe(item -> System.out.println(item.toString()));
		
	}
	
	public void facturaConProductos() {
		
		// Crear un flujo con 1 cliente
		Mono<Cliente> monoCliente = Mono.fromCallable(() -> 
				new Cliente("Juan", "12345678-A"));
		
		// Crear un flujo con 4 productos
		Mono<FacturaProductos> facturaMono = Mono.fromCallable( () -> {
			FacturaProductos fact = new FacturaProductos();
			fact.addProducto(new Producto(1, "Pantalla", 129.95));
			fact.addProducto(new Producto(2, "Teclado", 56));
			fact.addProducto(new Producto(3, "Raton", 29.50));
			fact.addProducto(new Producto(4, "Impresora", 85.25));
			return fact;
		});
				
		
		// Combinar ambos flujos
		monoCliente
			.flatMap(cliente -> facturaMono.map(f -> 
				new FacturaProductos(cliente, f.getProductos())))
			.subscribe(item -> System.out.println(item.toString()));
		
	}
	
	public void fluxAMono() {
		Mono<List<Factura>> mono = Flux.fromIterable(lista)
				.collectList();
				
		mono.subscribe(lista -> {
					lista.forEach(System.out::println);
				});
	}
	
	
	public void flujoFacturasReactivo() {
		
		Flux<Factura> facturas = Flux.fromIterable(lista)
				.map(fact -> new Factura(
						fact.getNumero(),
						fact.getDetalle().toUpperCase(),
						fact.getImporte()))
				// flatMap lo devuelve como un observable
				.flatMap(fact -> {
					if (fact.getDetalle().contains("COMPRA")) {
						return Mono.just(fact);
					} else {
						return Mono.empty();
					}
				})
				.doOnNext(fact -> System.out.println(fact));
		facturas.subscribe(item -> System.out.println(item.toString()));
	}
	
	public void flujoFacturas() {
		
		Flux<Factura> facturas = Flux.fromIterable(lista)
				.filter(fact -> fact.getImporte() > 200)
				// map modifica el elemento y lo devuelve al stream pero no es reactivo
				.map(fact -> new Factura(
						fact.getNumero(),
						fact.getDetalle().toUpperCase(),
						fact.getImporte()))
				.doOnNext(fact -> System.out.println(fact));
		facturas.subscribe();
	}
	
	public void flujoNumeros() {

		// Creamos un flujo de numeros
		Flux<Integer> numeros = Flux.just(1, 2, 3, 4, 5)
				.map(num -> num * 2)
				.doOnNext(item -> {
					if (item % 2 == 0) {
						//throw new RuntimeException("No me gustan los numeros pares");
					}
					System.out.println(item);
				})
				.map(num -> num / 2);
		
		// Hasta que no se subscribe no hace nada
		//numeros.subscribe(item -> System.out.println("Subscribe " + item));
		
		// Utilizar el subscribe para manejar errores
		numeros.subscribe(
				item -> System.out.println("Subscribe " + item),
				error -> System.out.println(error.getMessage()),
				
				new Runnable() {
					
					@Override
					public void run() {
						System.out.println("Fin");
					}
				}			
		);
		
	}
	

}
